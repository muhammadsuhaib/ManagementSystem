<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FormCModel extends Model
{
    protected $fillable=[


        'accountant_information'

    ];
}
