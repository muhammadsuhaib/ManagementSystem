<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2017
    </div>
    <strong>Copyright &copy; 2016-2017 <a href="www.e4510.jp">Kawai Shoji Group</a>.</strong> All rights
    reserved.
</footer>